#include "math.h"
#include <stdio.h>
// goal: read equations from a file and write them in a solved state to another
// file
//   NOTE: format details specified in instructions
// param qfile: file with math questions to solve
// param afile: file to write equations with answers in
// example:
//   qfile at start of function:
//     12 + 13
//     24 / 5
//     8 * 234
//     65 - 78
//     239 % 13
//   afile after function:
//      12 +  13 = 25
//      24 /   5 = 4
//       8 * 234 = 1872
//      65 -  78 = -13
//     239 %  13 = 5
//
// TODO: Complete the function
void solve(const char *qfile, const char *afile) {
 FILE *input = fopen(qfile, "r");
    if (input == NULL) {
        printf("Failed to open input file.\n");
        return;
    }
    
    FILE *output = fopen(afile, "w");
    if (output == NULL) {
        printf("Failed to open output file.\n");
        fclose(input);
        return;
    }

    int num1, num2, result;
    char operator;

    while (fscanf(input, "%d %c %d\n", &num1, &operator, &num2) == 3) {
        switch (operator) {
            case '+':
                result = num1 + num2;
                break;
            case '-':
                result = num1 - num2;
                break;
            case '*':
                result = num1 * num2;
                break;
            case '/':
                result = num1 / num2;
                break;
            case '%':
                result = num1 % num2;
                break;
            default:
                printf("Invalid operator.\n");
                continue;  // Skip processing this equation
        }
        fprintf(output, "%3d %c %3d = %d\n", num1, operator, num2, result);
    }

    fclose(input);
    fclose(output);
}

